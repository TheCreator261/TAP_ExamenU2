from flask import Flask, render_template, request, redirect, flash
import mysql.connector
from datetime import datetime

app = Flask(__name__)
app.secret_key = 'tu_clave_secreta'

def obtener_conexion():
    return mysql.connector.connect(host='localhost',
                                   user='root',
                                   password='26noviembre2005',
                                   database='citas')

def obtener_profesionales():
    conexion = obtener_conexion()
    try:
        cursor = conexion.cursor(dictionary=True)
        cursor.execute("SELECT * FROM Profesionales")
        return cursor.fetchall()
    finally:
        if conexion.is_connected():
            cursor.close()
            conexion.close()

def obtener_clientes():
    conexion = obtener_conexion()
    try:
        cursor = conexion.cursor(dictionary=True)
        cursor.execute("SELECT * FROM Clientes")
        return cursor.fetchall()
    finally:
        if conexion.is_connected():
            cursor.close()
            conexion.close()

def obtener_citas():
    conexion = obtener_conexion()
    try:
        cursor = conexion.cursor(dictionary=True)
        cursor.execute("SELECT * FROM Citas")
        return cursor.fetchall()
    finally:
        if conexion.is_connected():
            cursor.close()
            conexion.close()

@app.route('/')
def index():
    profesionales = obtener_profesionales()
    clientes = obtener_clientes()
    citas = obtener_citas()
    return render_template('index.html', profesionales=profesionales, clientes=clientes, citas=citas)

# Agregar Profesional
@app.route('/agregar_profesional', methods=['POST'])
def agregar_profesional():
    nombre = request.form['nombre']
    especialidad = request.form['especialidad']
    telefono = request.form['telefono']
    email = request.form['email']
    
    if not nombre or not especialidad or not telefono or not email:
        flash('Todos los campos son requeridos para agregar un profesional', 'error')
        return redirect('/')
    
    conexion = obtener_conexion()
    try:
        cursor = conexion.cursor()
        sql = "INSERT INTO Profesionales (nombre, especialidad, telefono, email) VALUES (%s, %s, %s, %s)"
        cursor.execute(sql, (nombre, especialidad, telefono, email))
        conexion.commit()
        flash('Profesional agregado correctamente', 'success')
    except mysql.connector.Error as err:
        print(f"Error al agregar profesional: {err}")
        flash('Error al agregar profesional', 'error')
    finally:
        if conexion.is_connected():
            cursor.close()
            conexion.close()
    return redirect('/')

# Eliminar Profesional
@app.route('/eliminar_profesional/<int:id>')
def eliminar_profesional(id):
    conexion = obtener_conexion()
    try:
        cursor = conexion.cursor()
        cursor.execute("DELETE FROM Profesionales WHERE id = %s", (id,))
        conexion.commit()
        flash('Profesional eliminado correctamente', 'success')
    except mysql.connector.Error as err:
        print(f"Error al eliminar profesional: {err}")
        flash('Error al eliminar profesional', 'error')
    finally:
        if conexion.is_connected():
            cursor.close()
            conexion.close()
    return redirect('/')

# Agregar Cliente
@app.route('/agregar_cliente', methods=['POST'])
def agregar_cliente():
    nombre = request.form['nombre']
    telefono = request.form['telefono']
    email = request.form['email']
    
    if not nombre or not telefono or not email:
        flash('Todos los campos son requeridos para agregar un cliente', 'error')
        return redirect('/')
    
    conexion = obtener_conexion()
    try:
        cursor = conexion.cursor()
        sql = "INSERT INTO Clientes (nombre, telefono, email) VALUES (%s, %s, %s)"
        cursor.execute(sql, (nombre, telefono, email))
        conexion.commit()
        flash('Cliente agregado correctamente', 'success')
    except mysql.connector.Error as err:
        print(f"Error al agregar cliente: {err}")
        flash('Error al agregar cliente', 'error')
    finally:
        if conexion.is_connected():
            cursor.close()
            conexion.close()
    return redirect('/')

# Eliminar Cliente
@app.route('/eliminar_cliente/<int:id>')
def eliminar_cliente(id):
    conexion = obtener_conexion()
    try:
        cursor = conexion.cursor()
        cursor.execute("DELETE FROM Clientes WHERE id = %s", (id,))
        conexion.commit()
        flash('Cliente eliminado correctamente', 'success')
    except mysql.connector.Error as err:
        print(f"Error al eliminar cliente: {err}")
        flash('Error al eliminar cliente', 'error')
    finally:
        if conexion.is_connected():
            cursor.close()
            conexion.close()
    return redirect('/')

# Agregar Cita
@app.route('/agregar_cita', methods=['POST'])
def agregar_cita():
    profesional_nombre = request.form['profesional_nombre']
    cliente_nombre = request.form['cliente_nombre']
    fecha_hora = request.form['fecha_hora']
    estado = request.form['estado']
    
    # Validación de fecha y hora
    try:
        fecha_hora_obj = datetime.strptime(fecha_hora, '%Y-%m-%d %H:%M')
    except ValueError:
        flash('La fecha y hora deben estar en el formato YYYY-MM-DD HH:MM', 'error')
        return redirect('/')
    
    if not profesional_nombre or not cliente_nombre or not estado:
        flash('Todos los campos son requeridos para agregar una cita', 'error')
        return redirect('/')
    
    conexion = obtener_conexion()
    try:
        cursor = conexion.cursor()
        sql = "INSERT INTO Citas (profesional_nombre, cliente_nombre, fecha_hora, estado) VALUES (%s, %s, %s, %s)"
        cursor.execute(sql, (profesional_nombre, cliente_nombre, fecha_hora_obj, estado))
        conexion.commit()
        flash('Cita agregada correctamente', 'success')
    except mysql.connector.Error as err:
        print(f"Error al agregar cita: {err}")
        flash('Error al agregar cita', 'error')
    finally:
        if conexion.is_connected():
            cursor.close()
            conexion.close()
    return redirect('/')

# Actualizar Cita
@app.route('/actualizar_cita/<int:id>', methods=['POST'])
def actualizar_cita(id):
    profesional_nombre = request.form['profesional_nombre']
    cliente_nombre = request.form['cliente_nombre']
    fecha_hora = request.form['fecha_hora']
    estado = request.form['estado']
    
    try:
        fecha_hora_obj = datetime.strptime(fecha_hora, '%Y-%m-%d %H:%M')
    except ValueError:
        flash('La fecha y hora deben estar en el formato YYYY-MM-DD HH:MM', 'error')
        return redirect('/')
    
    if not profesional_nombre or not cliente_nombre or not estado:
        flash('Todos los campos son requeridos para actualizar la cita', 'error')
        return redirect('/')
    
    conexion = obtener_conexion()
    try:
        cursor = conexion.cursor()
        sql = "UPDATE Citas SET profesional_nombre = %s, cliente_nombre = %s, fecha_hora = %s, estado = %s WHERE id = %s"
        cursor.execute(sql, (profesional_nombre, cliente_nombre, fecha_hora_obj, estado, id))
        conexion.commit()
        flash('Cita actualizada correctamente', 'success')
    except mysql.connector.Error as err:
        print(f"Error al actualizar cita: {err}")
        flash('Error al actualizar cita', 'error')
    finally:
        if conexion.is_connected():
            cursor.close()
            conexion.close()
    return redirect('/')

# Eliminar Cita
@app.route('/eliminar_cita/<int:id>')
def eliminar_cita(id):
    conexion = obtener_conexion()
    try:
        cursor = conexion.cursor()
        cursor.execute("DELETE FROM Citas WHERE id = %s", (id,))
        conexion.commit()
        flash('Cita eliminada correctamente', 'success')
    except mysql.connector.Error as err:
        print(f"Error al eliminar cita: {err}")
        flash('Error al eliminar cita', 'error')
    finally:
        if conexion.is_connected():
            cursor.close()
            conexion.close()
    return redirect('/')

if __name__ == '__main__':
    app.run(debug=True)